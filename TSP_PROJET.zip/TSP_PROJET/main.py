from experiment import run_experiments

run_experiments()