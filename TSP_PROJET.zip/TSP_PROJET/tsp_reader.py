import math

def read_tsp(filename):

    coords = []
    start = False

    with open(filename, "r") as f:

        for line in f:

            if "NODE_COORD_SECTION" in line:
                start = True
                continue

            if "EOF" in line:
                break

            if start:
                parts = line.strip().split()

                if len(parts) >= 3:
                    x = float(parts[1])
                    y = float(parts[2])
                    coords.append((x, y))

    return coords


def distance_matrix(coords):

    n = len(coords)

    dist = [[0]*n for _ in range(n)]

    for i in range(n):
        for j in range(n):

            xi, yi = coords[i]
            xj, yj = coords[j]

            dist[i][j] = math.sqrt((xi-xj)**2 + (yi-yj)**2)

    return dist