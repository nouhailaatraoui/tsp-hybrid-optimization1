def nearest_neighbor(dist):

    n = len(dist)

    visited = [False]*n
    tour = [0]

    visited[0] = True

    for _ in range(n-1):

        last = tour[-1]

        next_city = None
        best_dist = float("inf")

        for j in range(n):

            if not visited[j] and dist[last][j] < best_dist:
                best_dist = dist[last][j]
                next_city = j

        tour.append(next_city)
        visited[next_city] = True

    return tour


def tour_cost(tour, dist):

    cost = 0
    n = len(tour)

    for i in range(n):

        cost += dist[tour[i]][tour[(i+1) % n]]

    return cost