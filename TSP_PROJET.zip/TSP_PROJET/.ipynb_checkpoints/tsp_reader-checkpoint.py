{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "bb40e8ff",
   "metadata": {},
   "outputs": [],
   "source": [
    "import math\n",
    "\n",
    "def read_tsp(filename):\n",
    "\n",
    "    coords = []\n",
    "    start = False\n",
    "\n",
    "    with open(filename, \"r\") as f:\n",
    "\n",
    "        for line in f:\n",
    "\n",
    "            if \"NODE_COORD_SECTION\" in line:\n",
    "                start = True\n",
    "                continue\n",
    "\n",
    "            if \"EOF\" in line:\n",
    "                break\n",
    "\n",
    "            if start:\n",
    "                parts = line.split()\n",
    "                x = float(parts[1])\n",
    "                y = float(parts[2])\n",
    "                coords.append((x, y))\n",
    "\n",
    "    return coords\n",
    "\n",
    "\n",
    "def distance_matrix(coords):\n",
    "\n",
    "    n = len(coords)\n",
    "    dist = [[0]*n for _ in range(n)]\n",
    "\n",
    "    for i in range(n):\n",
    "        for j in range(n):\n",
    "\n",
    "            xi, yi = coords[i]\n",
    "            xj, yj = coords[j]\n",
    "\n",
    "            dist[i][j] = math.sqrt((xi-xj)**2 + (yi-yj)**2)\n",
    "\n",
    "    return dist"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "6c56e97f",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
