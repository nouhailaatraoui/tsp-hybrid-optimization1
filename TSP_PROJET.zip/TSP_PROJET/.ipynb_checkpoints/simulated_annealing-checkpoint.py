{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "9b44ed70",
   "metadata": {},
   "outputs": [],
   "source": [
    "import random\n",
    "import math\n",
    "from two_opt import two_opt_swap\n",
    "from nearest_neighbor import tour_cost\n",
    "\n",
    "\n",
    "def simulated_annealing(dist, initial_tour):\n",
    "\n",
    "    T = 1000\n",
    "    cooling = 0.995\n",
    "    Tmin = 1e-3\n",
    "\n",
    "    current = initial_tour\n",
    "    current_cost = tour_cost(current, dist)\n",
    "\n",
    "    best = current\n",
    "    best_cost = current_cost\n",
    "\n",
    "    n = len(initial_tour)\n",
    "\n",
    "    while T > Tmin:\n",
    "\n",
    "        i = random.randint(1, n-2)\n",
    "        k = random.randint(i+1, n-1)\n",
    "\n",
    "        candidate = two_opt_swap(current, i, k)\n",
    "\n",
    "        candidate_cost = tour_cost(candidate, dist)\n",
    "\n",
    "        delta = candidate_cost - current_cost\n",
    "\n",
    "        if delta < 0 or random.random() < math.exp(-delta/T):\n",
    "\n",
    "            current = candidate\n",
    "            current_cost = candidate_cost\n",
    "\n",
    "            if current_cost < best_cost:\n",
    "\n",
    "                best = current\n",
    "                best_cost = current_cost\n",
    "\n",
    "        T *= cooling\n",
    "\n",
    "    return best, best_cost"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "92c3dc13",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
