{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "f2db0cb5",
   "metadata": {},
   "outputs": [],
   "source": [
    "def nearest_neighbor(dist):\n",
    "\n",
    "    n = len(dist)\n",
    "\n",
    "    visited = [False]*n\n",
    "    tour = [0]\n",
    "\n",
    "    visited[0] = True\n",
    "\n",
    "    for _ in range(n-1):\n",
    "\n",
    "        last = tour[-1]\n",
    "        next_city = None\n",
    "        best = float(\"inf\")\n",
    "\n",
    "        for j in range(n):\n",
    "\n",
    "            if not visited[j] and dist[last][j] < best:\n",
    "\n",
    "                best = dist[last][j]\n",
    "                next_city = j\n",
    "\n",
    "        tour.append(next_city)\n",
    "        visited[next_city] = True\n",
    "\n",
    "    return tour\n",
    "\n",
    "\n",
    "def tour_cost(tour, dist):\n",
    "\n",
    "    cost = 0\n",
    "\n",
    "    for i in range(len(tour)-1):\n",
    "\n",
    "        cost += dist[tour[i]][tour[i+1]]\n",
    "\n",
    "    cost += dist[tour[-1]][tour[0]]\n",
    "\n",
    "    return cost"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "9dc6ced5",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
