{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "d0d1756e",
   "metadata": {},
   "outputs": [],
   "source": [
    "def two_opt_swap(tour, i, k):\n",
    "\n",
    "    new_tour = tour[:i]\n",
    "\n",
    "    new_tour += tour[i:k+1][::-1]\n",
    "\n",
    "    new_tour += tour[k+1:]\n",
    "\n",
    "    return new_tour"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "7f49fa44",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
