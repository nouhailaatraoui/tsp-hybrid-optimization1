import os
import time

from tsp_reader import read_tsp, distance_matrix
from nearest_neighbor import nearest_neighbor, tour_cost
from two_opt import two_opt
from simulated_annealing import simulated_annealing


def run_experiments():

    folder = "instances"

    files = [f for f in os.listdir(folder) if f.endswith(".tsp")]

    print("="*95)
    print(f"{'Instance':12} | {'NN Cost':10} | {'NN Time':8} | {'SA Cost':10} | {'SA Time':8} | {'Gain %':7}")
    print("="*95)

    for file in files:

        path = os.path.join(folder, file)

        # -----------------------------
        # Lecture de l'instance TSP
        # -----------------------------
        coords = read_tsp(path)
        dist = distance_matrix(coords)

        # -----------------------------
        # NEAREST NEIGHBOR
        # -----------------------------
        start = time.time()

        nn_tour = nearest_neighbor(dist)
        nn_cost = tour_cost(nn_tour, dist)

        nn_time = time.time() - start

        # -----------------------------
        # 2-OPT (amélioration locale)
        # -----------------------------
        improved_tour = two_opt(nn_tour, dist)

        # -----------------------------
        # SIMULATED ANNEALING
        # -----------------------------
        sa_tour, sa_cost, sa_time = simulated_annealing(dist, improved_tour)

        # -----------------------------
        # CALCUL DU GAIN
        # -----------------------------
        gain = ((nn_cost - sa_cost) / nn_cost) * 100

        # -----------------------------
        # AFFICHAGE
        # -----------------------------
        print(f"{file:12} | {nn_cost:10.2f} | {nn_time:8.4f} | {sa_cost:10.2f} | {sa_time:8.4f} | {gain:6.2f} %")

    print("="*95)