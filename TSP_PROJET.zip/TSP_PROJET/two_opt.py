import time
from nearest_neighbor import tour_cost


def two_opt_swap(tour, i, k):
    """
    Effectue un swap 2-opt entre les positions i et k
    """
    new_tour = tour[:i] + tour[i:k+1][::-1] + tour[k+1:]
    return new_tour


def two_opt(tour, dist, time_limit=5):
    """
    Amélioration locale 2-opt
    tour : tournée initiale
    dist : matrice des distances
    time_limit : limite de temps en secondes
    """

    start_time = time.time()

    best_tour = list(tour)
    best_cost = tour_cost(best_tour, dist)

    improved = True

    while improved:

        improved = False

        for i in range(1, len(best_tour) - 2):
            for k in range(i + 1, len(best_tour) - 1):

                # arrêter si le temps dépasse la limite
                if time.time() - start_time > time_limit:
                    return best_tour

                new_tour = two_opt_swap(best_tour, i, k)
                new_cost = tour_cost(new_tour, dist)

                if new_cost < best_cost:
                    best_tour = new_tour
                    best_cost = new_cost
                    improved = True

    return best_tour