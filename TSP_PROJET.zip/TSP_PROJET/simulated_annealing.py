import math
import random
import time
from nearest_neighbor import tour_cost

def simulated_annealing(dist, initial_tour):

    start_time = time.time()

    n = len(initial_tour)

    current_tour = list(initial_tour)
    current_cost = tour_cost(current_tour, dist)

    best_tour = list(current_tour)
    best_cost = current_cost

    # paramètres améliorés
    T = current_cost
    alpha = 0.995

    while T > 1e-3:

        for _ in range(10 * n):

            i, j = sorted(random.sample(range(n), 2))

            neighbor = current_tour[:i] + current_tour[i:j+1][::-1] + current_tour[j+1:]

            neighbor_cost = tour_cost(neighbor, dist)

            delta = neighbor_cost - current_cost

            if delta < 0 or random.random() < math.exp(-delta / T):

                current_tour = neighbor
                current_cost = neighbor_cost

                if current_cost < best_cost:

                    best_cost = current_cost
                    best_tour = list(current_tour)

        T *= alpha

        if time.time() - start_time > 20:
            break

    return best_tour, best_cost, time.time() - start_time